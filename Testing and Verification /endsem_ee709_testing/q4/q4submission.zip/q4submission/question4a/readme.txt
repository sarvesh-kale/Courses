note -> make sure you are in the tests directory of the cmu_bdd package .otherwise the -I and -L will fail !

$ gcc -o output q4a.c -I ../include -L ../lib -lbdd -lmem
$ ./output

To execute already compiled file attached in submission  
$ ./q4a
